import * as i0 from "@angular/core";
export type StatusBadgeKind = 'success' | 'error' | 'warning' | 'info' | 'neutral';
/**
 * Reusable pill badge for a semantic status, styled from the platform status design
 * tokens (light/dark aware). Part of the plugin UI kit: an external remote plugin can
 * import it from `@integration-hub/shared/ui` to render badges with the native look.
 * The label is projected: {@code <ih-status-badge status="success">Active</ih-status-badge>}.
 */
export declare class StatusBadgeComponent {
    readonly status: import("@angular/core").InputSignal<StatusBadgeKind>;
    static ɵfac: i0.ɵɵFactoryDeclaration<StatusBadgeComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<StatusBadgeComponent, "ih-status-badge", never, { "status": { "alias": "status"; "required": false; "isSignal": true; }; }, {}, never, ["*"], true, never>;
}
