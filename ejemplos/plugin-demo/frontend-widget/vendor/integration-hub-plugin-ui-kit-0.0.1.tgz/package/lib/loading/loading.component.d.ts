import * as i0 from "@angular/core";
export declare class LoadingComponent {
    readonly variant: import("@angular/core").InputSignal<"bar" | "skeleton">;
    readonly label: import("@angular/core").InputSignal<string | null>;
    readonly rows: import("@angular/core").InputSignal<number>;
    protected readonly skeletonRows: import("@angular/core").Signal<number[]>;
    static ɵfac: i0.ɵɵFactoryDeclaration<LoadingComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<LoadingComponent, "ih-loading", never, { "variant": { "alias": "variant"; "required": false; "isSignal": true; }; "label": { "alias": "label"; "required": false; "isSignal": true; }; "rows": { "alias": "rows"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}
