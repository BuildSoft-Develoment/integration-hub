import * as i0 from "@angular/core";
export declare class EmptyStateComponent {
    readonly icon: import("@angular/core").InputSignal<string | null>;
    readonly message: import("@angular/core").InputSignal<string>;
    readonly ctaLabel: import("@angular/core").InputSignal<string | null>;
    readonly ctaClick: import("@angular/core").OutputEmitterRef<void>;
    static ɵfac: i0.ɵɵFactoryDeclaration<EmptyStateComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<EmptyStateComponent, "ih-empty-state", never, { "icon": { "alias": "icon"; "required": false; "isSignal": true; }; "message": { "alias": "message"; "required": true; "isSignal": true; }; "ctaLabel": { "alias": "ctaLabel"; "required": false; "isSignal": true; }; }, { "ctaClick": "ctaClick"; }, never, never, true, never>;
}
