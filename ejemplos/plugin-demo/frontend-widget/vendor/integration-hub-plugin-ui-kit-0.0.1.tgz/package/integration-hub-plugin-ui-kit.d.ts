/**
 * Generated bundle index. Do not edit.
 */
/// <amd-module name="@integration-hub/plugin-ui-kit" />
export * from './index';
